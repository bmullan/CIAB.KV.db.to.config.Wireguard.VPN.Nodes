#!/bin/bash
source /usr/bin/kv-bash.sh

# Clear entire KV database

kvclear



