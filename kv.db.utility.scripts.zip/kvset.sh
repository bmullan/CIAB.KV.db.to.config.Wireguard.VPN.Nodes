#!/bin/bash
source /usr/bin/kv-bash.sh

key=$1
value=$2

kvset $key $value


