#!/bin/bash

source /usr/bin/kv-bash.sh

# Prompt the user for the VPN name
read -p "Enter the VPN name: " vpnname

# Prompt the user for the maximum number of nodes
read -p "Enter the maximum number of nodes: " maxnodes

#"============================================================================"
#" Now that we have the Master VXLan Wireguard Config file we need to"
#" populate our KV database with each entry using NODEXXX as the KEY"
#" and the Value being that NODEXXX's config extracted from the Master"
#"============================================================================"

# Define the input and output file names
config_file="$vpnname".conf
results="results.txt"

# Check if the input file exists
if [ ! -f "$config_file" ]; then
  echo "Error: Configuration file '$config_file' not found."
  exit 1
fi

nodenumber=001
currentnode="node"$nodenumber
while [ "$nodenumber" -le "$maxnodes" ]; do
  # Read each line of the file and store it in an array
  IFS=$'\n' read -d '' -r -a mycfg_array < "$config_file"

echo $IFS
exit

  # Join the elements of the array with a Line Feed character
  value=$(printf '%s\n' "${mycfg_array[@]}")

  kvset $currentnode $value
  nodenumber=$((nodenumber + 1))
  currentnode="node"$nodenumber
done


