#!/bin/bash
source /usr/bin/kv-bash.sh

key=$1

kvget $key


