#!/bin/bash
source /usr/bin/kv-bash.sh

# list all current KV pairs

kvlist

